% Load the data
dat=load('PotRo_L27771_TG.txt');
%TG_URoZ_L2744.txt
% Extract the data
V=dat(:,1)*1;
rho=dat(:,2)*1000;
z=dat(:,3);
n=1;j=1;
fid = fopen('amazon_june14_1988.txt','wt');
while n <= numel(z)-1

    if z(n)==z(n+1) 
        disp(n)
        rho(n)=(rho(n+1)+rho(n))/2;
        fprintf(fid,'%7i %14.7f %7i \n',V(n), rho(n), z(n));
        n=n+2;
    else
        fprintf(fid,'%7i %14.7f %7i \n',V(n), rho(n), z(n));
        n=n+1;
    end
    
end



