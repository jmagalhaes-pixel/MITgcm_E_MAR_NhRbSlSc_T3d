function density_profile

% Load the data
dat=load('amazon_june14_1988_4000.txt');
V=dat(:,1)*1;
rho=dat(:,2);
z=dat(:,3);

%-------------------
% constants
g=9.8;
rho_0=mean(rho);

figure;
plot(rho,z)
fid = fopen('amazon_june14_1988_10m.txt','wt');
j=1;
for n=1:10:numel(z)
    rho_mean(j)=mean(rho(n:n+9));
    z_mean(j)=z(n);
    fprintf(fid,'%7i %14.5f %7i \n',V(n), rho_mean(j), z_mean(j));
    j=j+1;
end
figure;
plot(rho_mean,z_mean)

for n=1:numel(rho)-1
N2(n)=(-g/rho_0)*(rho(n+1)-rho(n));
end

numel(z)
numel(N2)
z2=z(1:numel(N2))';
whos N2 z2

% -----------------
%   m�dia m�vel
% -----------------
[Y]=mediamovel(N2,51);

Y(find(Y<=0))=0;


figure;
plot(Y,z2)

end

function [Y]=mediamovel(X,MM)
[lin,N]=size(X);
Filtro=ones(1,MM)/MM;
MM2=(MM-1)/2; %assume-se que MM � �mpar e que o filtro � centrado
Y2=conv(X,Filtro);
[lin,col]=size(Y2); left=(col-(N-2*MM2))/2; %ZERO PADDING TO THE LEFT
Yvalid=Y2(left+1:1:left+(N-2*MM2)); % para corrigir o offset originado pela convolu��o
Y(1,1:N)=NaN; Y(MM2+1:N-MM2)=Yvalid;
return
end

