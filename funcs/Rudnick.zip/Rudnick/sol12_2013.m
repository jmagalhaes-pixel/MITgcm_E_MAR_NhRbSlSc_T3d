%script to demonstrate the central limit theorem
%

num=100000;
bin=[-5:0.1:5];
nvar=input('Number of random variables to sum ');

x=rand(nvar,num);
ii=(x <= 1/3);
x(ii)=6*x(ii)-4;
jj=(x > 2/3);
x(jj)=6*x(jj)-2;
kk=(~ii & ~jj);
x(kk)=6*x(kk)-3;

nx=histc(x(1,:),bin);
pdfx=nx/num/(bin(2)-bin(1));

bar(bin,pdfx,'histc');
xlabel('x');
ylabel('pdf(x)');

y=sum(x,1)*sqrt(3/19/nvar);
ny=hist(y,bin);
pdfy=ny/num/(bin(2)-bin(1));

figure
bar(bin,pdfy);
hold on;
plot(bin,normpdf(bin,0,1),'r');
hold off;
xlabel('y');
ylabel('pdf(y)');
title(['Sum of ' int2str(nvar) ' random variables']);
