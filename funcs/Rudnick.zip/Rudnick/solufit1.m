%Solve Homework #2.
%The data vector d is made up of each measurement of u followed by each 
%measurement of v.
%
	d=[35.5 53.5 49.2 33.5 43.5 21.3 30.4 24.8 18.4 25.5]'
%
%Set up G ordering the functions as 1 x y.
%
	H=[1 10 0; 1 0 10;1 -10 0; 1 0 -10; 1 0 0]
	G=[H zeros(size(H)); zeros(size(H)) H]
%
%Do the unconstrained problem and output m and dhat the estimated data.
%
	Gmg=(G'*G)\G'
	m=Gmg*d
	dhat=G*m
%
%Calculate the misfit.
%
	misfit=(dhat-d)'*(dhat-d)
%
%Calculate the vorticity and divergence and area-averaged velocity.
%
	cvort=[0 0 -1 0 1 0]'
	vort=cvort'*m
	cdiv=[0 1 0 0 0 1]'
	div=cdiv'*m
	cu=[1 0 0 0 0 0]'
   uav=cu'*m
	cv=[0 0 0 1 0 0]'
   vav=cv'*m
%
%Calculate the covariance matrix of m.
%
	sigma=3.0
	covm=sigma^2*Gmg*Gmg'
%
%Calculate the errors in vorticity and divergence, and area-averaged velocity.
%
	errvort=cvort'*covm*cvort
	errdiv=cdiv'*covm*cdiv
	erru=cu'*covm*cu
	errv=cv'*covm*cv
%
%Do the constrained calculation.
%
	F=cdiv'
	Gmg=(eye(size(covm))-(G'*G)\F'/(F/(G'*G)*F')*F)*Gmg
	m=Gmg*d
	dhat=G*m
	misfit=(dhat-d)'*(dhat-d)
	vort=cvort'*m
	div=cdiv'*m
   uav=cu'*m
   vav=cv'*m
	covm=sigma^2*Gmg*Gmg'
	erru=cu'*covm*cu
	errv=cv'*covm*cv
	errvort=cvort'*covm*cvort
	errdiv=cdiv'*covm*cdiv
