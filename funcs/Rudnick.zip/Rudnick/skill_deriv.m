%Script to solve problem of estimating skill in derivative.
%

noise=input('Noise? ');
skill=zeros(19,1);
ndata=[2:20]';
for n=2:20
   x=linspace(-1,1,n)';
   [X1,X2]=meshgrid(x);
   cov=1./(1+(X1-X2).^2)+noise*eye(n);
   cxx=-2*x./(1+x.^2).^2;
   skill(n-1)=(cxx'*(cov\cxx))/2;
end
plot(ndata,skill,'x');
set(gca,'xlim',[0 20],'ylim',[0 1]);
xlabel('Number of data');
ylabel('Skill');
title(['Noise = ' num2str(noise)]);
