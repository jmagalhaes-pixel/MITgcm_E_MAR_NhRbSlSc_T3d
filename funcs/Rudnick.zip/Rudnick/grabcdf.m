function x=grabcdf(file,var)
%function x=grabcdf(file,var) gets the variable var from netcdf file file.
%This is a wrapper function for nc_varget whose main purpose is to turn all
%variables into doubles.
%This serves as a replacement for the old grabcdf, which is used in several
%of my functions and scripts.

%D. Rudnick, December 28, 2010

x=double(nc_varget(file,var));
