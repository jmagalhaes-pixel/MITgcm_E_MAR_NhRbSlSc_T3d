%Script to solve interpolation problem using a covariance: 1/(1+(x/L)^2).
%

d=input('Data (2-vector for values at x=[-1 1])? ');
scale=input('e-folding scales? ');
noise=input('Noise? ');
d=d(:);
x=(-5:0.1:5)';
skill=zeros(length(x),length(scale));
y=zeros(size(skill));
for n=1:length(scale)
   cov=[1+noise 1./(1+(2/scale(n))^2); 1./(1+(2/scale(n))^2) 1+noise];
   cx=[1./(1+((x+1)/scale(n)).^2) 1./(1+((x-1)/scale(n)).^2)];
   skill(:,n)=diag(cx/cov*cx');
   y(:,n)=cx/cov*d;
end
figure;
plot(x,y),xlabel('x'),ylabel('y');
figure;
plot(x,skill),xlabel('x'),ylabel('skill')
