%script to make a plot for SIO 221B Homework #1, Problem 1.
%

alpha=128;
sigma=15;

mu=(-256:256)';
g=mu-2*alpha*sign(fix(mu/alpha));

Da=normcdf(alpha,mu,sigma);
Dma=normcdf(-alpha,mu,sigma);

meang=mu+2*alpha*(Dma-1+Da);

plot(mu,[g meang]);
xlabel('x, \mu');
legend('g','mean g');
axis('equal','tight');
set(gca,'xtick',(mu(1):alpha:mu(end)),'ytick',(-alpha:alpha:alpha));
grid on;
