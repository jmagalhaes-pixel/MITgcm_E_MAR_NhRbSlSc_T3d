%solution of homework problem to create joint normally distributed random
%variables
%

num=100000;
xlim=10;
nbin=100;
xx=2;
yy=0.25;
xy=0.5;

theta=0.5*atan(2*xy/(xx-yy));
xox=sqrt(xx*cos(theta)^2+2*xy*cos(theta)*sin(theta)+yy*sin(theta)^2);
yox=sqrt(yy*cos(theta)^2-2*xy*cos(theta)*sin(theta)+xx*sin(theta)^2);

x=xox*randn(num,1);
y=yox*randn(num,1);

i=1i;
z=x+i*y;
z=z*exp(i*theta);
x=real(z);
y=imag(z);

plot(x,y,'.');
axis equal
axis([-xlim xlim -xlim xlim]);
grid on;
xlabel('x');
ylabel('y');

bin=linspace(-xlim,xlim,nbin);
n=hist2d(x,y,bin,bin)/(bin(2)-bin(1))^2/num;

figure;
contourf(bin,bin,n');
axis equal
axis([-xlim xlim -xlim xlim]);
grid on;
xlabel('x');
ylabel('y');
colorbar;

disp(['<x>= ' num2str(mean(x))])
disp(['<y>= ' num2str(mean(y))])
disp(['<x^2>= ' num2str(mean(x.^2))])
disp(['<y^2>= ' num2str(mean(y.^2))])
disp(['<xy>= ' num2str(mean(x.*y))])
