%Matlab script to make an objective map using an objective function fit
%to approximate the mean.
%

%Some constants.  Take care in changing these.
nx=90; ny=100;
alon1=-25.5; alon2=-22.9;
alat1=35; alat2=36.7;
tokm=111.324; tokmt=tokm*cos(pi/180*(alat1+alat2)/2);
xl=0.0; xr=tokmt*(alon2-alon1);
yl=0.0; yr=tokm*(alat2-alat1);
xg=linspace(xl,xr,nx);
yg=linspace(yl,yr,ny);
nfunc=3;

data=grabcdf('/Users/rudnick/subduction/data/sub2s1.ctd.cdf','sigz');
lat=grabcdf('/Users/rudnick/subduction/data/sub2s1.ctd.cdf','latitude');
lon=grabcdf('/Users/rudnick/subduction/data/sub2s1.ctd.cdf','longitude');
depth=grabcdf('/Users/rudnick/subduction/data/sub2s1.ctd.cdf','depth');

%Ask for level, correlation lengths, angle, and error.
level=input('Input level (1-50) ');
xcor=input('Input x correlation length ');
ycor=input('Input y correlation length ');
phi=input('Input angle ');
err=input('Input error energy ')';
xcor2=xcor*xcor;
ycor2=ycor*ycor;
cosphi=cos(phi/180*pi);
sinphi=sin(phi/180*pi);

%Convert distances to km, and put data in vector d.
ii=find(~isnan(data(:,level)));
x=tokmt*(lon(ii)-alon1);
y=tokm*(lat(ii)-alat1);
d=data(ii,level);
nfact=length(d);
disp(sprintf('%5i data',nfact))

%Calculate the data-data covariance matrix E.
[X1,X2]=meshgrid(x);
[Y1,Y2]=meshgrid(y);
dx=X1-X2;
dy=Y1-Y2;
dxr=dx*cosphi-dy*sinphi;
dyr=dx*sinphi+dy*cosphi;
E=exp(-dxr.^2/xcor2-dyr.^2/ycor2);
E=E+err*eye(nfact);

%Calculate the data-grid points covariance matrix C.
C=zeros(nfact,nx*ny);
[Y,X]=meshgrid(yg,xg);
for n=1:nfact
   dx=X(:)'-x(n);
   dy=Y(:)'-y(n);
   dxr=dx*cosphi-dy*sinphi;
   dyr=dx*sinphi+dy*cosphi;
   C(n,:)=exp(-dxr.^2/xcor2-dyr.^2/ycor2);
end

%Calculate the matrix A to turn data into a grid.
m=1:nfunc;
F=fxy(m,x,y);
EF=E\F;
W=EF/(F'*EF);
EC=E\C;
f=fxy(m,X(:),Y(:))';
A=W*f+(eye(nfact)-W*F')*EC;

%Now calculate the grid.
grid=zeros(nx,ny);
grid(:)=A'*d;

%Calculate error grid.
ergrid=zeros(nx,ny);
EC=E*A;
for n=1:nx*ny   %this way saves memory
   ergrid(n)=A(:,n)'*(EC(:,n)-2*C(:,n))+1;
end
