function grid2=mask(grid,ergrid,thresh)
%Mask the grid according to the ergrid and a thresh value.
%

	grid2=grid;
	m=find(ergrid > thresh);
	grid2(m)=nan*ones(size(m));
