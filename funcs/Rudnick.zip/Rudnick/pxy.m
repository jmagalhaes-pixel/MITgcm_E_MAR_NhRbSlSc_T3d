%script to make contour plots.
%Run after offxy
%

thresh=input('Input error threshold ');

long=linspace(alon1,alon2,nx);
latg=linspace(alat1,alat2,ny);
contour(long,latg,mask(grid,ergrid,thresh)',[26:0.025:28]);
hold on;
[cc,hh]=contour(long,latg,mask(grid,ergrid,thresh)',[26:0.1:28],'linewidth',3);
plot(lon(ii),lat(ii),'kx');
hold off;
xlabel('Longitude');
ylabel('Latitude');
title([int2str(depth(level)) ' m']);
set(gca,'dataaspectratio',[1 cos(pi/180*(alat1+alat2)/2) 1]);
