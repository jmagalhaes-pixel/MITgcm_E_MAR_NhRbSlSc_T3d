%Solution to Homework #2.
%
%Here's the data.
%
	t=[2.5; 0; 4.0; 1.5];
	s=[34.9; 34.7; 34.4; 34.7];
	c=[0.90; 0.88; 0.87; 0.77];
	Q=3.8;
	lambda=2.3;
%
%Set up G and d.
%
	G=[ones(size(t)) t s c]';
	G(:,4)=-G(:,4)
	d=[0 -Q 0 lambda*c(4)]'
%
%Solve for the transports m.
%
	m=G\d
%
%The proportion of each water mass is:
%
	prop=m(1:3)/m(4)
%
%The residence time in years is:
%
	vol=6e17
	time=vol/m(4)/3600/24/365/1e6
	pause
%
%
%Now for question 2.
%
	G2=G;
	G2(4,:)=[]
	d2=d;
	d2(4)=[]
%
%The smallest solution is given by:
%
	m2=pinv(G2)*d2		%pinv is the pseudoinverse.
%
%This is unphysical since m(1), m(3), m(4) < 0.
%Find the null space and use it to make them > 0.
%
	[U2,S2,V2]=svd(G2);
%
%The null space is given by the 4th column of V2.
%Find the ratio of the smallest solution m2 to the null vector.
%
	v0=V2(:,4)
	rat=m2./v0
%
%Find the largest absolute value of rat which corresponds with a negative
%transport and find the solution:
%
	[ratmax,imax]=max(-sign(m2).*abs(rat))
	m2pos=m2-rat(imax)*v0
%
%The proportions and residence time are:
%
	prop2=m2pos(1:3)/m2pos(4)
	time2=vol/m2pos(4)/3600/24/365/1e6
	pause
%
%
%And finally question 3.
%
	G3=G;
	G3(:,5)=[0 1 0 0]'
	d3=d;
	d3(2)=0
%
%First calculate the smallest L2 norm model.
%Also find the null space.
%
	m3=pinv(G3)*d3
	[U3,S3,V3]=svd(G3);
	v03=V3(:,5)
%
%The solution with the smallest L2 norm of the transports is given
%by mT=m3+alpha*v03 where alpha is chosen to minimize mT'*WT*mT and
%WT is given by:
%
	WT=eye(5);
	WT(5,5)=0
%
%Now alpha is just:
%
	alpha=-(v03'*WT*m3)/(v03'*WT*v03)
%
%And the smallest transport solution is:
%
	mT=m3+alpha*v03
	pause
%
%Which is clearly unphysical since it implies geothermal cooling!!
%Now the solution with the smallest L2 norm of Q is given by the
%same procedure with a different weighting matrix.
%
	WQ=zeros(5);
	WQ(5,5)=1
	alphaQ=-(v03'*WQ*m3)/(v03'*WQ*v03)
	mQ=m3+alphaQ*v03
%
%Which has Q=0.
%The proportions and residence time are:
%
	prop3=mQ(1:3)/mQ(4)
	time3=vol/mQ(4)/3600/24/365/1e6
