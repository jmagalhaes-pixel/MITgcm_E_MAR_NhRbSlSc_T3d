%script to read in fasinex temperature data.
%

t=grabcdf('fas-temp.nc','temperature');
time=grabcdf('fas-temp.nc','time');
depth=grabcdf('fas-temp.nc','depth');
lat=grabcdf('fas-temp.nc','latitude');
lon=grabcdf('fas-temp.nc','longitude');
moor=cellstr(char(grabcdf('fas-temp.nc','mooring')));
