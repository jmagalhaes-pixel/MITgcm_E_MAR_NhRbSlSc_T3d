function R=fxy(m,x,y)
%Calculate matrix of n by m matrix R of m functions evaluated at n
%locations x, y.
%
%Not much to this one.
%
	R=ones(length(x),length(m));
	R(:,2)=x;
	R(:,3)=y;
